The sources for the vector diagrams (in `xml/`) can be edited with
[diagrams.net](https://app.diagrams.net/) - formerly called "draw.io".

The SVG files in `svg/` are exported versions of those.

Note that diagrams.net allows you to directly save and export the files
to your cocotb fork/branch on GitHub, producing git commits.
